CREATE DATABASE funnel_analysis;
USE funnel_analysis;

SHOW TABLES;

DESCRIBE ecommerce;

SELECT * FROM ecommerce LIMIT 10;

SELECT
    SUM(CASE WHEN added_to_cart IS NULL THEN 1 ELSE 0 END) AS null_cart,
    SUM(CASE WHEN purchased IS NULL THEN 1 ELSE 0 END) AS null_purchase,
    SUM(CASE WHEN cart_abandoned IS NULL THEN 1 ELSE 0 END) AS null_abandoned
FROM ecommerce;

SELECT DISTINCT device_type FROM ecommerce ORDER BY device_type;
SELECT DISTINCT marketing_channel FROM ecommerce ORDER BY marketing_channel;
SELECT DISTINCT payment_method FROM ecommerce ORDER BY payment_method;
SELECT DISTINCT product_category FROM ecommerce ORDER BY product_category;
SELECT DISTINCT user_type FROM ecommerce ORDER BY user_type;
SELECT DISTINCT visit_season FROM ecommerce ORDER BY visit_season;
SELECT DISTINCT session_duration_bucket FROM ecommerce ORDER BY session_duration_bucket;

SELECT
    COUNT(*)                                                        AS total_visits,
    SUM(added_to_cart)                                              AS added_to_cart,
    SUM(purchased)                                                  AS purchases,
    SUM(cart_abandoned)                                             AS abandoned_carts,
    ROUND(100 * SUM(added_to_cart) / COUNT(*), 2)                  AS visit_to_cart_pct,
    ROUND(100 * SUM(purchased) / SUM(added_to_cart), 2)            AS cart_to_purchase_pct,
    ROUND(100 * SUM(cart_abandoned) / SUM(added_to_cart), 2)       AS cart_abandonment_pct,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_conversion_pct
FROM ecommerce;

SELECT
    device_type,
    COUNT(*)                                                        AS sessions,
    SUM(added_to_cart)                                              AS carts,
    SUM(purchased)                                                  AS purchases,
    SUM(cart_abandoned)                                             AS abandoned,
    ROUND(100 * SUM(added_to_cart) / COUNT(*), 2)                  AS visit_to_cart_pct,
    ROUND(100 * SUM(purchased) / SUM(added_to_cart), 2)            AS cart_to_purchase_pct,
    ROUND(100 * SUM(cart_abandoned) / SUM(added_to_cart), 2)       AS abandonment_rate,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr,
    ROUND(AVG(revenue), 2)                                         AS avg_revenue
FROM ecommerce
GROUP BY device_type
ORDER BY overall_cvr DESC;

SELECT
    marketing_channel,
    COUNT(*)                                                        AS sessions,
    SUM(added_to_cart)                                              AS carts,
    SUM(purchased)                                                  AS purchases,
    SUM(cart_abandoned)                                             AS abandoned,
    ROUND(100 * SUM(added_to_cart) / COUNT(*), 2)                  AS visit_to_cart_pct,
    ROUND(100 * SUM(purchased) / SUM(added_to_cart), 2)            AS cart_to_purchase_pct,
    ROUND(100 * SUM(cart_abandoned) / SUM(added_to_cart), 2)       AS abandonment_rate,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr,
    ROUND(SUM(revenue), 2)                                         AS total_revenue
FROM ecommerce
GROUP BY marketing_channel
ORDER BY overall_cvr DESC;

SELECT
    user_type,
    COUNT(*)                                                        AS sessions,
    SUM(added_to_cart)                                              AS carts,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(added_to_cart) / COUNT(*), 2)                  AS visit_to_cart_pct,
    ROUND(100 * SUM(purchased) / SUM(added_to_cart), 2)            AS cart_to_purchase_pct,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr
FROM ecommerce
GROUP BY user_type
ORDER BY overall_cvr DESC;

SELECT
    payment_method,
    COUNT(*)                                                        AS sessions,
    SUM(added_to_cart)                                              AS carts,
    SUM(purchased)                                                  AS purchases,
    SUM(cart_abandoned)                                             AS abandoned,
    ROUND(100 * SUM(purchased) / SUM(added_to_cart), 2)            AS cart_to_purchase_pct,
    ROUND(100 * SUM(cart_abandoned) / SUM(added_to_cart), 2)       AS abandonment_rate
FROM ecommerce
GROUP BY payment_method
ORDER BY abandonment_rate DESC;

SELECT
    product_category,
    COUNT(*)                                                        AS sessions,
    SUM(added_to_cart)                                              AS carts,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr,
    ROUND(SUM(revenue), 2)                                         AS total_revenue,
    ROUND(AVG(CASE WHEN purchased=1 THEN revenue END), 2)          AS avg_order_value
FROM ecommerce
GROUP BY product_category
ORDER BY overall_cvr DESC;

SELECT
    session_duration_bucket,
    COUNT(*)                                                        AS sessions,
    SUM(added_to_cart)                                              AS carts,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(added_to_cart) / COUNT(*), 2)                  AS visit_to_cart_pct,
    ROUND(100 * SUM(purchased) / SUM(added_to_cart), 2)            AS cart_to_purchase_pct,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr
FROM ecommerce
GROUP BY session_duration_bucket
ORDER BY overall_cvr DESC;

SELECT
    visit_season,
    COUNT(*)                                                        AS sessions,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr
FROM ecommerce
GROUP BY visit_season
ORDER BY overall_cvr DESC;

SELECT
    visit_weekday,
    COUNT(*)                                                        AS sessions,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr
FROM ecommerce
GROUP BY visit_weekday
ORDER BY overall_cvr DESC;

SELECT
    device_type,
    marketing_channel,
    COUNT(*)                                                        AS sessions,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS overall_cvr
FROM ecommerce
GROUP BY device_type, marketing_channel
ORDER BY overall_cvr DESC
LIMIT 15;

SELECT
    CASE
        WHEN purchased = 1 THEN 'Purchased'
        WHEN added_to_cart = 1 AND purchased = 0 THEN 'Cart Abandoned'
        ELSE 'Browsed Only'
    END AS funnel_stage,
    COUNT(*)                                                        AS users,
    ROUND(AVG(time_on_site_sec), 2)                                AS avg_time_sec,
    ROUND(AVG(pages_viewed), 2)                                    AS avg_pages,
    ROUND(AVG(quantity), 2)                                        AS avg_quantity
FROM ecommerce
GROUP BY funnel_stage;

SELECT
    CASE
        WHEN discount_percent = 0 THEN 'No Discount'
        WHEN discount_percent < 20 THEN 'Low (1-19%)'
        WHEN discount_percent < 40 THEN 'Medium (20-39%)'
        ELSE 'High (40%+)'
    END AS discount_tier,
    COUNT(*)                                                        AS sessions,
    SUM(purchased)                                                  AS purchases,
    ROUND(100 * SUM(purchased) / COUNT(*), 2)                      AS conversion_rate,
    ROUND(AVG(CASE WHEN purchased=1 THEN revenue END), 2)          AS avg_order_value
FROM ecommerce
GROUP BY discount_tier
ORDER BY conversion_rate DESC;

SELECT
    purchased,
    ROUND(AVG(rating), 2)                                          AS avg_rating,
    MIN(rating)                                                     AS min_rating,
    MAX(rating)                                                     AS max_rating
FROM ecommerce
GROUP BY purchased;

SELECT
    CASE
        WHEN revenue < 500 THEN 'Under ₹500'
        WHEN revenue < 1500 THEN '₹500-1500'
        WHEN revenue < 3000 THEN '₹1500-3000'
        WHEN revenue < 5000 THEN '₹3000-5000'
        ELSE 'Above ₹5000'
    END AS revenue_bucket,
    COUNT(*)                                                        AS buyers,
    ROUND(AVG(revenue), 2)                                         AS avg_revenue
FROM ecommerce
WHERE purchased = 1
GROUP BY revenue_bucket
ORDER BY avg_revenue ASC;
